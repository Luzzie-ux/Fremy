import { Interaction, SlashCommandBuilder } from "discord.js";
export declare const ping: {
    data: SlashCommandBuilder;
    execute: (interaction: Interaction) => Promise<void>;
};
//# sourceMappingURL=ping.d.ts.map