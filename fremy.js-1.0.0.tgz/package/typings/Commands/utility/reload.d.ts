import { Interaction, SlashCommandBuilder } from "discord.js";
declare const reload: {
    data: SlashCommandBuilder;
    execute: (interaction: Interaction) => Promise<void>;
};
export default reload;
//# sourceMappingURL=reload.d.ts.map