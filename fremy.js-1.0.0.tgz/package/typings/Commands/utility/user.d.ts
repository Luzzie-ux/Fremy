import { Interaction, SlashCommandBuilder } from "discord.js";
declare const user: {
    data: SlashCommandBuilder;
    execute: (interaction: Interaction) => Promise<void>;
};
export { user };
//# sourceMappingURL=user.d.ts.map