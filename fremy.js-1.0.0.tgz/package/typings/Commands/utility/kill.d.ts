import { SlashCommandBuilder, Interaction } from "discord.js";
declare const kill: {
    data: SlashCommandBuilder;
    execute: (interaction: Interaction) => Promise<void>;
};
export { kill };
//# sourceMappingURL=kill.d.ts.map