import { Collection, ContextMenuCommandBuilder, SlashCommandBuilder, Events } from "discord.js";
import type { Client, Interaction } from "discord.js";
interface DiscordJSCommand {
    data: SlashCommandBuilder | ContextMenuCommandBuilder;
    execute: (i: Interaction) => Promise<void>;
}
interface DiscordJSEvent {
    name: string;
    once?: boolean;
    execute: (...args: unknown[]) => Promise<void> | void;
}
export declare function isSlash(data: unknown): data is SlashCommandBuilder;
export declare function isContext(data: unknown): data is ContextMenuCommandBuilder;
export declare function isEvent(name: unknown): name is Events;
declare abstract class Manager<T> {
    collection: Collection<string, T>;
    abstract isType(value: unknown): value is T;
    abstract loadPath(path: string): Promise<void>;
    loadItem(name: string, item: T): void;
    loadList(list: Record<string, T>): void;
    __load__(dir: string, isValid: (v: unknown) => v is T): Promise<T[]>;
    get keys(): string[];
    get values(): T[];
    get(key: string): T | undefined;
    set(key: string, value: T): Collection<string, T>;
    has(key: string): boolean;
}
declare class CommandManager extends Manager<DiscordJSCommand> {
    isType(value: unknown): value is DiscordJSCommand;
    loadPath(path: string): Promise<void>;
    register(required: {
        token: string;
        clientId: string;
        guildId?: string;
    }): Promise<void>;
    dispatch(interaction: Interaction): Promise<void>;
    private _replyWithError;
}
declare class EventManager extends Manager<DiscordJSEvent> {
    isType(value: unknown): value is DiscordJSEvent;
    loadPath(path: string): Promise<void>;
    deploy(client: Client): void;
}
export { Manager, CommandManager, EventManager, DiscordJSEvent, DiscordJSCommand, };
//# sourceMappingURL=Manager.d.ts.map