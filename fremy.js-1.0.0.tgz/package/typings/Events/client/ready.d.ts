import { Events, Client } from "discord.js";
declare const ready: {
    name: Events;
    once: boolean;
    execute(client: Client): void;
};
export { ready };
//# sourceMappingURL=ready.d.ts.map