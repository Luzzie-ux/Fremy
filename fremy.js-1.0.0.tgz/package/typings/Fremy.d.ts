import { Client, GatewayIntentBits, Interaction } from "discord.js";
import { Manager, CommandManager, EventManager, DiscordJSEvent, DiscordJSCommand, isSlash, isContext, isEvent } from "./Manager.js";
type Intent = GatewayIntentBits | IntentName | Array<GatewayIntentBits | IntentName>;
type IntentName = keyof typeof GatewayIntentBits;
interface JSONConfig {
    token: string;
    intents?: string[];
    clientId?: string;
    guildId?: string;
    [key: string]: unknown;
}
declare class Wrapper {
    #private;
    constructor(configs: JSONConfig);
    static fromEnv(env?: NodeJS.ProcessEnv, prefix?: string): Wrapper;
    addExtra(key: string, value: unknown): void;
    addIntents(intents: Intent): void;
    createClient(): Client;
    startClient(load_defaults?: boolean): Promise<void>;
    stopClient(): Promise<void>;
    loadCmds(path: string): Promise<void>;
    loadCmds(list: Record<string, DiscordJSCommand>): Promise<void>;
    registerCmds(): Promise<void>;
    dispatchCmds(interaction: Interaction): Promise<void>;
    loadEvents(path: string): Promise<void>;
    loadEvents(list: Record<string, DiscordJSEvent>): Promise<void>;
    deployEvents(client: Client): void;
    set clientId(clientId: string);
    set guildId(guildId: string);
    set extras(extras: Record<string, unknown>);
    get intents(): GatewayIntentBits[];
    get clientId(): string;
    get guildId(): string;
    get extras(): Record<string, unknown>;
    get client(): Client<boolean> | undefined;
    get commands(): CommandManager;
    get events(): EventManager;
}
export { Wrapper as Fremy };
export { Manager, EventManager, CommandManager, DiscordJSEvent, DiscordJSCommand, isSlash, isContext, isEvent, };
//# sourceMappingURL=Fremy.d.ts.map